package com.example.gridcomposeapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.gridcomposeapp.ui.theme.AppButton
import com.example.gridcomposeapp.ui.theme.AppTextField
import com.example.gridcomposeapp.ui.theme.AppTitle

data class InsertColumnsScreenState(
    val columns: String = ""
)

@Composable
fun InsertColumnsScreenContent(
    state: InsertColumnsScreenState,
    onColumnsChange: (String) -> Unit,
    onNextClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AppTitle("Insert Number of Columns")

            Spacer(modifier = Modifier.weight(1f))

            AppTextField(
                value = state.columns,
                onValueChange = onColumnsChange,
                label = "Number of columns"
            )

            Spacer(modifier = Modifier.weight(1f))

            AppButton(
                text = "Show Grid",
                onClick = onNextClick,
                enabled = state.columns.isNotEmpty() && state.columns.toIntOrNull() != null
            )
        }
    }
}

@Composable
fun InsertColumnsScreen(
    navController: NavController,
    rows: String,
    modifier: Modifier = Modifier
) {
    var columns by rememberSaveable { mutableStateOf("") }

    val state = InsertColumnsScreenState(columns = columns)

    InsertColumnsScreenContent(
        state = state,
        onColumnsChange = { columns = it },
        onNextClick = {
            navController.navigate("grid/$rows/$columns")
        },
        modifier = modifier
    )
}