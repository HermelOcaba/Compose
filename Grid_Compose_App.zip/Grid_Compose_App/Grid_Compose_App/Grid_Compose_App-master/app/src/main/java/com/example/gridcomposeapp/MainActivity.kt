package com.example.gridcomposeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.gridcomposeapp.ui.theme.GridComposeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GridComposeAppTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "insertRows"
    ) {
        composable("insertRows") {
            InsertRowsScreen(navController = navController)
        }
        composable(
            "insertColumns/{rows}",
            arguments = listOf(navArgument("rows") { type = NavType.StringType })
        ) { backStackEntry ->
            val rows = backStackEntry.arguments?.getString("rows") ?: ""
            InsertColumnsScreen(
                navController = navController,
                rows = rows
            )
        }
        composable(
            "grid/{rows}/{columns}",
            arguments = listOf(
                navArgument("rows") { type = NavType.StringType },
                navArgument("columns") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val rows = backStackEntry.arguments?.getString("rows") ?: ""
            val columns = backStackEntry.arguments?.getString("columns") ?: ""
            GridScreen(
                rows = rows,
                columns = columns
            )
        }
    }
}